<x-guest-layout>
    <x-authentication-card>
        <x-slot name="logo">
            <x-authentication-card-logo />
        </x-slot>

        <x-validation-errors class="mb-4" />

        <form method="POST" action="{{ route('register') }}">
            @csrf

            <div>
                <x-label for="name" value="{{ __('Name') }}" />
                <x-input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            </div>

            <div class="mt-4">
                <x-label for="email" value="{{ __('Email') }}" />
                <x-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autocomplete="username" />

                <x-input id="kab_kota_id" class="block mt-1 w-full" type="hidden" name="kab_kota" />
                <x-input id="kecamatan_id" class="block mt-1 w-full" type="hidden" name="kecamatan" />
            </div>

            <div class="mt-4">
                <x-label for="user_type" value="{{ __('User Type') }}" />
                <!-- <x-input id="user_type" class="block mt-1 w-full" type="text" name="user_type" :value="old('user_type')" required /> -->
                <select class="block mt-1 w-full form-select" id="user_type" name="user_type">
                    <option value="A">Admin Provinsi</option>
                    <option value="B">Admin Kabupaten/Kota</option>
                    <option value="C">Admin Kecamatan</option>
                    <option value="D">Admin Desa/Kelurahan</option>
                </select>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="kab_kota">Kabupaten/Kota</label>
                        @if(Auth::user()->user_type == "A")
                            <select name="kab_kota" id="kab_kota" class="form-control">
                                <option value="">Pilih Kabupaten/Kota</option>
                                @foreach($kab_kota as $kk)
                                <option value="{{$kk->id}}">{{$kk->nama_kab_kota}}</option>
                                @endforeach
                            </select>
                        @endif
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="kecamatan">Kecamatan</label>
                        @if(Auth::user()->user_type == "A")
                            <select name="kecamatan" id="kecamatan" class="form-control">
                                <option value="">Pilih Kecamatan</option>
                            </select>
                        @endif
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <x-label for="password" value="{{ __('Password') }}" />
                <x-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="new-password" />
            </div>

            <div class="mt-4">
                <x-label for="password_confirmation" value="{{ __('Confirm Password') }}" />
                <x-input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" required autocomplete="new-password" />
            </div>

            @if (Laravel\Jetstream\Jetstream::hasTermsAndPrivacyPolicyFeature())
                <div class="mt-4">
                    <x-label for="terms">
                        <div class="flex items-center">
                            <x-checkbox name="terms" id="terms" required />

                            <div class="ms-2">
                                {!! __('I agree to the :terms_of_service and :privacy_policy', [
                                        'terms_of_service' => '<a target="_blank" href="'.route('terms.show').'" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">'.__('Terms of Service').'</a>',
                                        'privacy_policy' => '<a target="_blank" href="'.route('policy.show').'" class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">'.__('Privacy Policy').'</a>',
                                ]) !!}
                            </div>
                        </div>
                    </x-label>
                </div>
            @endif

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="{{ route('login') }}">
                    {{ __('Already registered?') }}
                </a>

                <x-button class="ms-4">
                    {{ __('Register') }}
                </x-button>
            </div>
        </form>
    </x-authentication-card>
</x-guest-layout>
