

<?php $__env->startSection('content'); ?>
<?php
    $no = 1;
?>
<div class="content content-wrapper">
    <div class="content-header">
        <section class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <!-- <div class="row"> -->
                                    <!-- <div class="col-md-4"> -->
                                    <div>
                                        <h3 class="card-title">Histori Verifikasi Data</h3>
                                    </div>
                                <!-- </div> -->
                            </div>
                            <!-- <div class="col-md container-fluid"> -->
                            <div class="card-header">
                                <form class="row" action="<?php echo e(route('verifikasi.search')); ?>" method="GET">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-md">
                                        <select name="tahun" id="tahun" class="form-control">
                                            <option value="">Pilih Tahun</option>
                                            <?php for($t=2022; $t<2026; $t++): ?>
                                            <option value="<?php echo e($t); ?>"><?php echo e($t); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="kab_kota">Kabupaten/Kota</label> -->
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <option value="">Pilih Kabupaten/Kota</option>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="kecamatan">Kecamatan</label> -->
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kc->id); ?>"><?php echo e($kc->nama_kecamatan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="desa_kel">Desa/Kelurahan</label> -->
                                        <select name="desa_kel" id="desa_kel" class="form-control p-1">
                                            <option value="">Pilih Desa/Kelurahan</option>
                                        </select>
                                    </div>
                                    <div class="col-md">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Tahun</th>
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                        <th>Kabupaten/Kota</th>
                                        <?php elseif(Auth::user()->user_type == "B"): ?>
                                        <th>Kecamatan</th>
                                        <?php endif; ?>
                                        <th>Status Pengajuan</th>
                                        <th>Tanggal Pengajuan</th>
                                        <th>Status Verifikasi</th>
                                        <th>Tanggal Verifikasi</th>
                                        <?php if(Auth::user()->user_type == "A" OR Auth::user()->user_type == "B"): ?>
                                            <th>Aksi</th>
                                        <?php endif; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $verifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($v == ''): ?>
                                                <!-- <tr><td><h3>Tidak ada data</h3></td></tr> -->
                                                <tr>
                                                    <td>1</td>
                                                    <td>2</td>
                                                    <td>3</td>
                                                    <td>4</td>
                                                    <td>5</td>
                                                    <td>6</td>
                                                    <td>7</td>
                                                    <td>8</td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($no++); ?></td>
                                                    <td><?php echo e($v->tahun); ?></td>
                                                    <?php if(Auth::user()->user_type == "A"): ?>
                                                        <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($v->daerah == $kk->id): ?>
                                                            <td><?php echo e($kk->nama_kab_kota); ?></td>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif(Auth::user()->user_type == "B"): ?>
                                                        <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($v->daerah == $kc->id): ?>
                                                            <td><?php echo e($kc->nama_kecamatan); ?></td>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                    <?php if($v->status_pengajuan == true): ?>
                                                    <td><button class="btn btn-sm btn-success">Sudah diajukan</button></td>
                                                    <?php elseif($v->status_pengajuan == false): ?>
                                                    <td><button class="btn btn-sm btn-danger">Belum diajukan</button></td>
                                                    <?php endif; ?>

                                                    <td><?php echo e($v->tanggal_pengajuan); ?></td>

                                                    <?php if($v->status_verifikasi == 0): ?>
                                                    <td><button class="btn btn-sm btn-warning">Menunggu diverifikasi</button></td>
                                                    <?php elseif($v->status_verifikasi == 1): ?>
                                                    <td><button class="btn btn-sm btn-success">Sudah diverifikasi</button></td>
                                                    <?php elseif($v->status_verifikasi == 2): ?>
                                                    <td><button class="btn btn-sm btn-danger">Belum diverifikasi</button></td>
                                                    <?php endif; ?>
                                                    
                                                    <?php if($v->status_verifikasi == 0): ?>
                                                    <td>Menunggu diverifikasi</td>
                                                    <?php elseif($v->status_verifikasi == 1): ?>
                                                    <td><?php echo e($v->tanggal_verifikasi); ?></td>
                                                    <?php elseif($v->status_verifikasi == 2): ?>
                                                    <td>Belum diverifikasi</td>
                                                    <?php endif; ?>
                                                    
                                                    <?php if(Auth::user()->user_type == "A" OR Auth::user()->user_type == "B"): ?>
                                                        <?php if($v->status_verifikasi == 1): ?>
                                                        <td>Sudah diverifikasi<br><p><small>Catatan: <?php echo e($v->catatan); ?></small></p></td>
                                                        <?php elseif($v->status_verifikasi == 0 OR $v->status_verifikasi == 2): ?>
                                                        <td>
                                                            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-sm-<?php echo e($v->id); ?>">
                                                                <i class="fas fa-check"></i> Verifikasi
                                                            </button>
                                                            <?php if($v->status_verifikasi == 2): ?>
                                                            <p><small>Catatan: <?php echo e($v->catatan); ?></small></p>
                                                            <?php endif; ?>
                                                        </td>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                Halaman : <?php echo e($verifikasi->currentPage()); ?> |
                                Jumlah Data : <?php echo e($verifikasi->total()); ?> |
                                Data per Halaman : <?php echo e($verifikasi->perPage()); ?>

                                <?php echo e($verifikasi->links()); ?>

                            </div>
                        </div>
                    <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?php $__currentLoopData = $verifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-sm-<?php echo e($vk->id); ?>">
<div class="modal-dialog modal-sm">
    <div class="modal-content">
    <div class="modal-header">
        <h6 class="modal-title">Verifikasi (<?php if(Auth::user()->user_type == "A"): ?>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($v->daerah == $kk->id): ?>
                                                        <?php echo e($kk->nama_kab_kota); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php elseif(Auth::user()->user_type == "B"): ?>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($v->daerah == $kc->id): ?>
                                                        <?php echo e($kc->nama_kecamatan); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?> 
                                            <?php echo e($v->tahun); ?> )</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <form action="<?php echo e(route('verifikasi.update', $v->id)); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

            <div>
                <textarea class="form-control" name="catatan" id="catatan" placeholder="Catatan&hellip;"></textarea>
            </div>
            <div class="row m-3">
                <div class="col-sm-6">
                    <input class="form-check-input" type="radio" name="verifikasi" value="1">
                    <label class="form-check-label">Verifikasi</label>
                </div>
                <div class="col-sm-6">
                    <input class="form-check-input" type="radio" name="verifikasi" value="2">
                    <label class="form-check-label">Tolak</label>
                </div>
            </div>
        </div>
        <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
        </form>
    </div>
    <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/admin/verifikasi/verifikasi.blade.php ENDPATH**/ ?>