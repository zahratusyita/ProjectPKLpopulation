<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button class="btn btn-light" type="submit"><i class="fas fa-sign-out-alt"> Logout</i></button>
        </form>
      </li>
    </ul>
  </nav>
  <!-- /.navbar --><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/layouts/include/navbar.blade.php ENDPATH**/ ?>