<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link d-flex">
      <div class="image">
        <img src="<?php echo e(asset('assets/dist/img/logo_ntb.png')); ?>" alt="Logo NTB" class="brand-image img-circle elevation-3" style="opacity: .8">
      </div>
      <div class="info">
        <span class="brand-text font-weight-light"><small>Dinas PKH Provinsi NTB</small></span>
      </div>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('assets/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('home')); ?>" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('peternak')); ?>" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Peternak
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('ternak')); ?>" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Ternak
              </p>
            </a>
          </li>
          <?php if(Auth::user()->user_type == 'A' OR Auth::user()->user_type == 'B'): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('verifikasi')); ?>" class="nav-link">
              <i class="nav-icon fas fa-check-circle"></i>
              <p>
                Verifikasi
              </p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(Auth::user()->user_type == 'A'): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('user')); ?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Akun User
              </p>
            </a>
          </li>
          <?php endif; ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>