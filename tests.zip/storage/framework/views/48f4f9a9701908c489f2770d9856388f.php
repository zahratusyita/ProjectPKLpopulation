

<?php $__env->startSection('content'); ?>
<div class="content content-wrapper">
    <div class="content-header">
        <section class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <h3 class="card-title">Data Ternak 
                                        <a href="<?php echo e(route('ternak.form')); ?>" class="btn btn-sm btn-primary ml-2"><i class="fas fa-plus"></i> Tambah</a>
                                        <?php if(!empty($_REQUEST['tahun']) OR !empty($_REQUEST['search']) OR !empty($_REQUEST['kab_kota']) OR !empty($_REQUEST['kecamatan']) OR !empty($_REQUEST['desa_kel'])): ?>
                                        <a href="<?php echo e(route('ternak.export').'?tahun='.$_REQUEST['tahun'].'&kab_kota='.$_REQUEST['kab_kota'].'&kecamatan='.$_REQUEST['kecamatan'].'&desa_kel='.$_REQUEST['desa_kel'].'&search='.$_REQUEST['search']); ?>" class="btn btn-md btn-success ml-2"><i class="fas fa-table"></i> Export</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('ternak.export').'?tahun=&kab_kota=&kecamatan=&desa_kel=&search='); ?>" class="btn btn-md btn-success ml-2"><i class="fas fa-table"></i> Export</a>
                                        <?php endif; ?>
                                    </h3>
                                </div>
                                <div class="col container-fluid">
                                    <form class="row float-right" action="<?php echo e(route('peternak.search')); ?>" method="GET">
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Auth::user()->user_type == 'B' OR Auth::user()->user_type == 'C'): ?>
                                        <a href="<?php echo e(route('ajukan')); ?>" class="btn btn-sm btn-primary ml-2"><i class="fas fa-paper-plane"></i> Ajukan Data Tahun Ini</a>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            </div>
                            
                            <div class="card-header">
                                <form class="row" action="<?php echo e(route('ternak.search')); ?>" method="GET">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col">
                                        <select name="tahun" id="tahun" class="form-control">
                                            <option value="">Pilih Tahun</option>
                                            <?php for($t=2022; $t<2026; $t++): ?>
                                            <option value="<?php echo e($t); ?>"><?php echo e($t); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md">
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <option value="">Pilih Kabupaten/Kota</option>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="kecamatan">Kecamatan</label> -->
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kc->id); ?>"><?php echo e($kc->nama_kecamatan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="desa_kel">Desa/Kelurahan</label> -->
                                        <select name="desa_kel" id="desa_kel" class="form-control p-1">
                                            <option value="">Pilih Desa/Kelurahan</option>
                                        </select>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="search">Peternak</label> -->
                                        <input type="text" name="search" id="search" class="form-control" placeholder="Nama Peternak">
                                    </div>
                                    <div class="col-md">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                <tr>
                                    <th rowspan="2" style="vertical-align:middle;">No.</th>
                                    <th rowspan="2" style="vertical-align:middle;">Peternak</th>
                                    <th rowspan="2" style="vertical-align:middle;">Desa/Kelurahan</th>
                                    <th colspan="11" style="text-align:center;">Jumlah</th>
                                    <?php if(Auth::user()->user_type == "C"): ?>
                                    <th>Aksi</th>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                <th>Sapi</th>
                                    <th>Kerbau</th>
                                    <th>Kuda</th>
                                    <th>Kambing</th>
                                    <th>Babi</th>
                                    <th>Domba</th>
                                    <th>Ayam Ras</th>
                                    <th>Ayam Buras</th>
                                    <th>Ayam Layer</th>
                                    <th>Itik</th>
                                    <th>Puyuh</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ternak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($t == ''): ?>
                                            <tr>
                                                <td>1</td>
                                                <td>2</td>
                                                <td>3</td>
                                                <td>4</td>
                                                <td>5</td>
                                                <td>6</td>
                                                <td>7</td>
                                                <td>8</td>
                                                <td>9</td>
                                                <td>10</td>
                                                <td>11</td>
                                                <td>12</td>
                                                <td>13</td>
                                                <td>14</td>
                                                <td>15</td>
                                            </tr>
                                        <?php else: ?>
                                            <tr>
                                                <td><?php echo e($t->id); ?></td>
                                                <td><?php echo e($t->nama); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $desa_kel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($t->desa_kel_id == $dk->id): ?>
                                                            <?php echo e($dk->nama_desa_kel); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e($t->sapi_anak_jantan + $t->sapi_anak_betina + $t->sapi_muda_jantan + $t->sapi_muda_betina + $t->sapi_dewasa_jantan + $t->sapi_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->kerbau_anak_jantan + $t->kerbau_anak_betina + $t->kerbau_muda_jantan + $t->kerbau_muda_betina + $t->kerbau_dewasa_jantan + $t->kerbau_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->kuda_anak_jantan + $t->kuda_anak_betina + $t->kuda_muda_jantan + $t->kuda_muda_betina + $t->kuda_dewasa_jantan + $t->kuda_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->kambing_anak_jantan + $t->kambing_anak_betina + $t->kambing_muda_jantan + $t->kambing_muda_betina + $t->kambing_dewasa_jantan + $t->kambing_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->babi_anak_jantan + $t->babi_anak_betina + $t->babi_muda_jantan + $t->babi_muda_betina + $t->babi_dewasa_jantan + $t->babi_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->domba_anak_jantan + $t->domba_anak_betina + $t->domba_muda_jantan + $t->domba_muda_betina + $t->domba_dewasa_jantan + $t->domba_dewasa_betina + 0); ?></td>
                                                <td><?php echo e($t->ayam_ras + 0); ?></td>
                                                <td><?php echo e($t->ayam_buras + 0); ?></td>
                                                <td><?php echo e($t->ayam_petelur + 0); ?></td>
                                                <td><?php echo e($t->itik + 0); ?></td>
                                                <td><?php echo e($t->puyuh + 0); ?></td>
                                                <?php if(Auth::user()->user_type == "C"): ?>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="<?php echo e(route('ternak.edit', $t->id)); ?>" class="btn btn-sm btn-warning mr-2"><i class="fas fa-edit"></i> Edit</a>
                                                        <form action="<?php echo e(route('ternak.delete', $t->id)); ?>" method="POST">
                                                            <?php echo e(csrf_field()); ?>

                                                            <button class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda  yakin untuk menghapus data ?')"><i class="fas fa-trash-alt"></i> Hapus</button>
                                                        </form>
                                                    </div>
                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                Halaman : <?php echo e($ternak->currentPage()); ?> |
                                Jumlah Data : <?php echo e($ternak->total()); ?> |
                                Data per Halaman : <?php echo e($ternak->perPage()); ?>

                                <?php echo e($ternak->links()); ?>

                            </div>
                        </div>
                    <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/admin/ternak/ternak.blade.php ENDPATH**/ ?>