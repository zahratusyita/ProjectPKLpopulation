

<?php $__env->startSection('content'); ?>
<?php
    $no = 1;
?>
<div class="content content-wrapper">
    <div class="content-header">
        <section class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <!-- <div class="row"> -->
                                    <!-- <div class="col-md-4"> -->
                                    <div>
                                        <h3 class="card-title">Data Peternak 
                                            <a href="<?php echo e(route('peternak.form')); ?>" class="btn btn-sm btn-primary ml-2"><i class="fas fa-plus"></i> Tambah</a>
                                            <?php if(!empty($_REQUEST['kab_kota']) OR !empty($_REQUEST['kecamatan']) OR !empty($_REQUEST['desa_kel']) OR !empty($_REQUEST['search'])): ?>
                                            <a href="<?php echo e(route('peternak.export').'?kab_kota='.$_REQUEST['kab_kota'].'&kecamatan='.$_REQUEST['kecamatan'].'&desa_kel='.$_REQUEST['desa_kel'].'&search='.$_REQUEST['search']); ?>" class="btn btn-sm btn-success ml-2"><i class="fas fa-table"></i> Export</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('peternak.export').'?kab_kota=&kecamatan=&desa_kel=&search='); ?>" class="btn btn-sm btn-success ml-2"><i class="fas fa-table"></i> Export</a>
                                            <?php endif; ?>
                                        </h3>
                                    </div>
                                <!-- </div> -->
                            </div>
                            <!-- <div class="col-md container-fluid"> -->
                            <div class="card-header">
                                <form class="row" action="<?php echo e(route('peternak.search')); ?>" method="GET">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-md">
                                        <!-- <label for="kab_kota">Kabupaten/Kota</label> -->
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <option value="">Pilih Kabupaten/Kota</option>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="kecamatan">Kecamatan</label> -->
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kc->id); ?>"><?php echo e($kc->nama_kecamatan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="desa_kel">Desa/Kelurahan</label> -->
                                        <select name="desa_kel" id="desa_kel" class="form-control p-1">
                                            <option value="">Pilih Desa/Kelurahan</option>
                                        </select>
                                    </div>
                                    <div class="col-md">
                                        <!-- <label for="search">Peternak</label> -->
                                        <input type="text" name="search" id="search" class="form-control" placeholder="Nama Peternak">
                                    </div>
                                    <div class="col-md">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap">
                                    <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>NIK</th>
                                        <th>Nama</th>
                                        <th>No. Hp</th>
                                        <th>Desa/Kelurahan</th>
                                        <?php if(Auth::user()->user_type == "C"): ?>
                                            <th>Aksi</th>
                                        <?php endif; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $peternak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($p == ''): ?>
                                                <!-- <tr><td><h3>Tidak ada data</h3></td></tr> -->
                                                <tr>
                                                    <td>1</td>
                                                    <td>2</td>
                                                    <td>3</td>
                                                    <td>4</td>
                                                    <td>5</td>
                                                    <td>6</td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($no++); ?></td>
                                                    <td><?php echo e($p->nik); ?></td>
                                                    <td><?php echo e($p->nama); ?></td>
                                                    <td><?php echo e($p->hp); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = $desa_kel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($p->desa_kel_id == $dk->id): ?>
                                                                <?php echo e($dk->nama_desa_kel); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <?php if(Auth::user()->user_type == "C"): ?>
                                                        <td>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('peternak.edit', $p->id)); ?>" class="btn btn-sm btn-warning mr-2"><i class="fas fa-edit"></i> Edit</a>
                                                                <form action="<?php echo e(route('peternak.delete', $p->id)); ?>" method="POST">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda  yakin untuk menghapus data ?')"><i class="fas fa-trash-alt"></i> Hapus</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                Halaman : <?php echo e($peternak->currentPage()); ?> |
                                Jumlah Data : <?php echo e($peternak->total()); ?> |
                                Data per Halaman : <?php echo e($peternak->perPage()); ?>

                                <?php echo e($peternak->links()); ?>

                            </div>
                        </div>
                    <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/admin/peternak/peternak.blade.php ENDPATH**/ ?>