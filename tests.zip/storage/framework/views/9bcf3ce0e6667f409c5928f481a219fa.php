

<?php $__env->startSection('content'); ?>
<?php
    $no = 1;
?>
<div class="content content-wrapper">
    <div class="content-header">
        <section class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <h3 class="card-title">Data User 
                                        <a href="<?php echo e(route('user.form')); ?>" class="btn btn-sm btn-primary ml-2"><i class="fas fa-plus"></i> Tambah</a>
                                    </h3>
                                </div>
                            </div>

                            <div class="card-header">
                                <form class="row" action="<?php echo e(route('user.search')); ?>" method="GET">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-md">
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <option value="">Pilih Kabupaten/Kota</option>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kab_kota" id="kab_kota" class="form-control">
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <?php if(Auth::user()->user_type == "A"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                            </select>
                                        <?php elseif(Auth::user()->user_type == "B" or Auth::user()->user_type == "C"): ?>
                                            <select name="kecamatan" id="kecamatan" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kc->id); ?>"><?php echo e($kc->nama_kecamatan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md">
                                        <input type="text" name="search" id="search" class="form-control" placeholder="Nama User">
                                    </div>
                                    <div class="col-md">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Type</th>
                                    <th>Kabupaten/Kota</th>
                                    <th>Kecamatan</th>
                                    <th>Aksi</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($u->name); ?></td>
                                        <td><?php echo e($u->email); ?></td>

                                        <?php if($u->user_type == "A"): ?>
                                        <td>Admin Provinsi</td>
                                            <td><center>-</center></td>
                                            <td><center>-</center></td>
                                        <?php elseif($u->user_type == "B"): ?>
                                        <td>Admin Kab./Kota</td>
                                            <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($u->kab_kota_id == $kk->id): ?>
                                                    <td><center><?php echo e($kk->nama_kab_kota); ?></center></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <td><center>-</center></td>
                                        <?php elseif($u->user_type == "C"): ?>
                                        <td>Admin Kecamatan</td>
                                            <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($u->kab_kota_id == $kk->id): ?>
                                                    <td><center><?php echo e($kk->nama_kab_kota); ?></center></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($u->kecamatan_id == $kc->id): ?>
                                                    <td><center><?php echo e($kc->nama_kecamatan); ?></center></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('user.edit', $u->id)); ?>" class="btn btn-sm btn-warning mr-2"><i class="fas fa-edit"></i> Edit</a>
                                                <form action="<?php echo e(route('user.delete', $u->id)); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda  yakin untuk menghapus data ?')"><i class="fas fa-trash-alt"></i> Hapus</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                Halaman : <?php echo e($user->currentPage()); ?> |
                                Jumlah Data : <?php echo e($user->total()); ?> |
                                Data per Halaman : <?php echo e($user->perPage()); ?>

                                <?php echo e($user->links()); ?>

                            </div>
                        </div>
                    <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/admin/user/user.blade.php ENDPATH**/ ?>