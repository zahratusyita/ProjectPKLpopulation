

<?php $__env->startSection('content'); ?>
<div class="content content-wrapper">
    <div class="content-header">
        <section class="container">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Update Peternak</h3>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form action="<?php echo e(route('peternak.update', $peternak->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="nik">NIK</label>
                                            <input type="text" class="form-control" name="nik" id="nik" value="<?php echo e($peternak->nik); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="nama">Nama</label>
                                            <input type="text" class="form-control" name="nama" id="nama" value="<?php echo e($peternak->nama); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="tempat_lahir">Tempat Lahir</label>
                                            <input type="text" class="form-control" name="tempat_lahir" id="tempat_lahir" value="<?php echo e($peternak->tempat_lahir); ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="tanggal_lahir">Tanggal Lahir</label>
                                            <div class="input-group date">
                                                <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo e($peternak->tanggal_lahir); ?>"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="kab_kota">Kabupaten/Kota</label>
                                            <select name="kab_kota" id="kab_kota_" class="form-control">
                                                <option value="">Pilih Kabupaten/Kota</option>
                                                <?php $__currentLoopData = $kab_kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>" <?php if($peternak->kab_kota_id == $kk->id): ?> selected <?php endif; ?>><?php echo e($kk->nama_kab_kota); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="kecamatan">Kecamatan</label>
                                            <select name="kecamatan" id="kecamatan_" class="form-control">
                                                <option value="">Pilih Kecamatan</option>
                                                <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kc->id); ?>" <?php if($peternak->kecamatan_id == $kc->id): ?> selected <?php endif; ?>><?php echo e($kc->nama_kecamatan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="desa_kel">Desa/Kelurahan</label>
                                            <select name="desa_kel" id="desa_kel_" class="form-control">
                                                <option value="">Pilih Desa/Kelurahan</option>
                                                <?php $__currentLoopData = $desa_kel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dk->id); ?>" <?php if($peternak->desa_kel_id == $dk->id): ?> selected <?php endif; ?>><?php echo e($dk->nama_desa_kel); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <textarea name="alamat" id="alamat" class="form-control"><?php echo e($peternak->alamat); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="hp">Nomor Hp</label>
                                    <input type="number" class="form-control" name="hp" id="hp" placeholder="Hp" value="<?php echo e($peternak->hp); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="agama">Agama</label>
                                    <select name="agama" id="agama" class="form-control">
                                        <option value="">Pilih Agama</option>
                                        <option value="1" <?php if($peternak->agama == 1): ?> selected <?php endif; ?>>Islam</option>
                                        <option value="2" <?php if($peternak->agama == 2): ?> selected <?php endif; ?>>Kristen Katolik</option>
                                        <option value="3" <?php if($peternak->agama == 3): ?> selected <?php endif; ?>>Kristen Protestan</option>
                                        <option value="4" <?php if($peternak->agama == 4): ?> selected <?php endif; ?>>Hindu</option>
                                        <option value="5" <?php if($peternak->agama == 5): ?> selected <?php endif; ?>>Buddha</option>
                                        <option value="6" <?php if($peternak->agama == 6): ?> selected <?php endif; ?>>Konghucu</option>
                                    </select>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\population\resources\views/admin/peternak/edit_peternak.blade.php ENDPATH**/ ?>